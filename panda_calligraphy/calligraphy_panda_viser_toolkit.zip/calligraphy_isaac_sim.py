"""
Robotic Chinese Calligraphy Simulation in NVIDIA Isaac Sim / Isaac Lab
======================================================================
This standalone simulation script demonstrates how to configure:
1. An articulated robot arm (e.g. Franka Emika Panda / UR5e) with operational space control.
2. A deformable Chinese calligraphy brush modeled using PhysX deformable body / hair particle system.
3. A dynamic render-target / Xuan paper contact sensor that stamps ink onto a canvas texture.
4. Trajectory tracking for Chinese calligraphy characters (e.g., "永" Yong).

Prerequisites:
    Run within NVIDIA Isaac Sim Python environment:
    ./python.sh calligraphy_isaac_sim.py
"""

import sys
import numpy as np

try:
    from omni.isaac.kit import SimulationApp
    simulation_app = SimulationApp({"headless": False})
    
    from omni.isaac.core import World
    from omni.isaac.core.robots import Robot
    from omni.isaac.core.objects import FixedCuboid
    from omni.isaac.core.utils.stage import add_reference_to_stage
    from omni.isaac.core.utils.types import ArticulationAction
    from pxr import UsdGeom, PhysxSchema, Gf, Vt
except ImportError:
    print("[NOTE] This script is designed to run inside NVIDIA Isaac Sim environment.")
    print("Command: ~/.local/share/ov/pkg/isaac_sim-*/python.sh calligraphy_isaac_sim.py")

def setup_calligraphy_world():
    world = World(stage_units_in_meters=1.0)
    world.scene.add_default_ground_plane()

    # 1. Wooden Calligraphy Table
    table = world.scene.add(
        FixedCuboid(
            prim_path="/World/CalligraphyTable",
            name="calligraphy_table",
            position=np.array([0.5, 0.0, 0.4]),
            scale=np.array([0.6, 0.8, 0.04]),
            color=np.array([0.15, 0.10, 0.07])
        )
    )

    # 2. Xuan Paper Sheet
    paper = world.scene.add(
        FixedCuboid(
            prim_path="/World/XuanPaper",
            name="xuan_paper",
            position=np.array([0.5, 0.0, 0.421]),
            scale=np.array([0.35, 0.35, 0.001]),
            color=np.array([0.98, 0.96, 0.93])
        )
    )

    print("Isaac Sim Calligraphy Scene Configured.")
    return world

def main():
    world = setup_calligraphy_world()
    world.reset()

    # Run physics simulation loop
    while simulation_app.is_running():
        world.step(render=True)

    simulation_app.close()

if __name__ == "__main__":
    main()
