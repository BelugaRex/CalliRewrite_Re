"""
Franka Emika Panda Robotic Chinese Calligraphy Simulator in Viser
=================================================================
This script simulates a 7-DOF Franka Emika Panda robotic arm controlling a
flexible Chinese calligraphy brush to write authentic calligraphy on Xuan paper.

Key Features:
- Official Franka Emika Panda 7-DOF URDF and mesh visualization via Viser.
- Damped Least-Squares (DLS) Inverse Kinematics for 7-axis Cartesian trajectory tracking.
- Non-linear deformable brush tuft mechanics (Hertzian normal force & splaying).
- High-resolution dynamic Xuan paper canvas (1024x1024) with authentic ink bleed.
- Classical Chinese character trajectories (永, 福, 中, 一) with the Eight Principles of Yong.
- Comprehensive Viser GUI controls (Cartesian IK sliders, 7 joint sliders, physics parameters).

Usage:
    python calligraphy_panda_viser_sim.py
    Then open http://localhost:8080 in your browser.
"""

from __future__ import annotations
import sys
import time
import math
import numpy as np
from PIL import Image, ImageDraw

import viser
import viser.transforms as tf

# Try importing ViserUrdf and robot_descriptions
HAS_ROBOT_DESCRIPTIONS = False
try:
    from robot_descriptions.loaders.yourdfpy import load_robot_description
    from viser.extras import ViserUrdf
    HAS_ROBOT_DESCRIPTIONS = True
except ImportError:
    pass


# ==============================================================================
# 1. Franka Emika Panda Kinematic Model (7-DOF)
# ==============================================================================
class PandaKinematics:
    """
    Kinematic model and Numerical Inverse Kinematics (DLS) for Franka Emika Panda.
    Joint limits based on Franka Emika specifications (radians).
    """
    JOINT_LIMITS = [
        (-2.8973, 2.8973),  # panda_joint1
        (-1.7628, 1.7628),  # panda_joint2
        (-2.8973, 2.8973),  # panda_joint3
        (-3.0718, -0.0698), # panda_joint4
        (-2.8973, 2.8973),  # panda_joint5
        (-0.0175, 3.7525),  # panda_joint6
        (-2.8973, 2.8973),  # panda_joint7
    ]

    # Standard Franka Panda DH / Link parameters (meters)
    # Base to flange distance along links:
    # d1=0.333, a1=0, a2=0, d3=0.316, a3=0.0825, a4=-0.0825, d5=0.384, d7=0.107, tool=0.22 (brush)
    NOMINAL_REST_Q = np.array([0.0, -0.6, 0.0, -2.2, 0.0, 1.6, 0.785])

    def __init__(self, tool_length=0.22):
        self.tool_length = tool_length # Flange to brush ferrule tip

    def forward_kinematics(self, q: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """
        Calculates end-effector (brush tip) position and orientation matrix for joint angles q (7,).
        Uses standard Franka DH frame transformations.
        """
        # DH parameters for Panda: [a, d, alpha, theta_offset]
        dh_params = [
            (0.0,      0.333, -np.pi/2, 0.0),
            (0.0,      0.0,    np.pi/2, 0.0),
            (0.0825,   0.316,  np.pi/2, 0.0),
            (-0.0825,  0.0,   -np.pi/2, 0.0),
            (0.0,      0.384,  np.pi/2, 0.0),
            (0.088,    0.0,    np.pi/2, 0.0),
            (0.0,      0.107,  0.0,     0.0)
        ]

        T = np.eye(4)
        for i in range(7):
            a, d, alpha, theta_off = dh_params[i]
            theta = q[i] + theta_off
            ct, st = np.cos(theta), np.sin(theta)
            ca, sa = np.cos(alpha), np.sin(alpha)

            T_i = np.array([
                [ct, -st * ca,  st * sa, a * ct],
                [st,  ct * ca, -ct * sa, a * st],
                [0.0, sa,       ca,      d],
                [0.0, 0.0,      0.0,     1.0]
            ])
            T = T @ T_i

        # Tool offset (brush along Z axis of flange)
        T_tool = np.eye(4)
        T_tool[2, 3] = self.tool_length
        T_end = T @ T_tool

        pos = T_end[:3, 3]
        rot = T_end[:3, :3]
        return pos, rot

    def compute_jacobian(self, q: np.ndarray) -> np.ndarray:
        """Numerical Jacobian calculation for 3D position (3x7)."""
        eps = 1e-5
        J = np.zeros((3, 7))
        p0, _ = self.forward_kinematics(q)

        for i in range(7):
            q_plus = q.copy()
            q_plus[i] += eps
            p_plus, _ = self.forward_kinematics(q_plus)
            J[:, i] = (p_plus - p0) / eps

        return J

    def solve_ik(self, target_pos: np.ndarray, current_q: np.ndarray, max_iters=25, tol=1e-4) -> np.ndarray:
        """
        Damped Least Squares (DLS) Inverse Kinematics with nullspace projection toward rest pose.
        """
        q = current_q.copy()
        lambda_damp = 0.04
        k_null = 0.15

        for _ in range(max_iters):
            curr_pos, _ = self.forward_kinematics(q)
            err = target_pos - curr_pos
            if np.linalg.norm(err) < tol:
                break

            J = self.compute_jacobian(q)
            # DLS formula: J_dls = J^T (J J^T + lambda^2 I)^-1
            JJT = J @ J.T + (lambda_damp ** 2) * np.eye(3)
            J_dls = J.T @ np.linalg.inv(JJT)

            # Nullspace biasing toward comfortable posture
            null_proj = np.eye(7) - J_dls @ J
            delta_q_null = null_proj @ (k_null * (self.NOMINAL_REST_Q - q))

            delta_q = J_dls @ err + delta_q_null
            # Clamping step size
            max_step = 0.25
            step_norm = np.linalg.norm(delta_q)
            if step_norm > max_step:
                delta_q = (delta_q / step_norm) * max_step

            q += delta_q

            # Clamp to joint limits
            for i in range(7):
                low, high = self.JOINT_LIMITS[i]
                q[i] = np.clip(q[i], low, high)

        return q


# ==============================================================================
# 2. Deformable Calligraphy Brush Mechanics & Xuan Paper Canvas
# ==============================================================================
class CalligraphyBrushTuft:
    """Non-linear elastic soft tuft model for Chinese calligraphy brush."""
    def __init__(self, length=0.045, stiffness=1.2, splay_factor=1.4):
        self.length = length          # 45 mm
        self.stiffness = stiffness    # elasticity modulus (Wolf / Goat hair)
        self.splay_factor = splay_factor
        self.paper_z = 0.002          # Table paper surface height in meters
        self.ink_level = 100.0        # %
        self.trail = []

    def evaluate_contact(self, nominal_tip_pos: np.ndarray, velocity: np.ndarray) -> dict:
        """
        Computes penetration depth, normal force Fn, splayed footprint radius, and bending lag.
        """
        penetration = max(0.0, self.paper_z - nominal_tip_pos[2])
        is_contact = penetration > 1e-4

        if is_contact:
            # Hertzian contact force model
            normal_force = self.stiffness * (penetration ** 1.25) * 600.0
            # Splayed footprint radius: R = R0 + k_splay * sqrt(delta)
            base_r = 0.0016
            footprint_r = base_r + self.splay_factor * np.sqrt(penetration) * 0.05

            # Constrain tip to paper surface with friction drag lag
            actual_tip = nominal_tip_pos.copy()
            actual_tip[2] = self.paper_z
            speed = np.linalg.norm(velocity[:2])
            if speed > 1e-4:
                lag = min(0.012, penetration * 0.85)
                actual_tip[:2] -= (velocity[:2] / speed) * lag

            return {
                "contact": True,
                "penetration": penetration,
                "normal_force": normal_force,
                "footprint_radius": footprint_r,
                "actual_tip": actual_tip
            }
        else:
            return {
                "contact": False,
                "penetration": 0.0,
                "normal_force": 0.0,
                "footprint_radius": 0.0,
                "actual_tip": nominal_tip_pos
            }


class XuanPaperCanvas:
    """1024x1024 Rice Paper (宣纸) raster with 米字格 guide grid and capillary ink bleed."""
    def __init__(self, resolution=1024, physical_width=0.34, physical_height=0.34, origin_xy=(0.55, 0.0)):
        self.res = resolution
        self.pw = physical_width
        self.ph = physical_height
        self.ox, self.oy = origin_xy # center of paper in world coordinates
        self.image = Image.new("RGBA", (self.res, self.res), (251, 247, 238, 255))
        self.draw = ImageDraw.Draw(self.image)
        self.draw_grid()

    def draw_grid(self):
        pad = int(self.res * 0.06)
        w, h = self.res, self.res
        # Traditional vermilion guide lines (米字格)
        grid_color = (194, 53, 49, 75)
        self.draw.rectangle([pad, pad, w - pad, h - pad], outline=grid_color, width=3)
        # Center cross
        self.draw.line([(w // 2, pad), (w // 2, h - pad)], fill=grid_color, width=2)
        self.draw.line([(pad, h // 2), (w - pad, h // 2)], fill=grid_color, width=2)
        # Diagonals
        self.draw.line([(pad, pad), (w - pad, h - pad)], fill=grid_color, width=1)
        self.draw.line([(w - pad, pad), (pad, h - pad)], fill=grid_color, width=1)

    def deposit_ink(self, world_x: float, world_y: float, radius: float, normal_force: float, bleed_factor=0.7):
        # Convert world (m) to canvas pixel coordinates
        rx = (world_x - (self.ox - self.pw / 2.0)) / self.pw
        ry = ((self.oy + self.ph / 2.0) - world_y) / self.ph

        px = int(rx * self.res)
        py = int(ry * self.res)
        pr = max(2, int((radius / self.pw) * self.res))

        if 0 <= px < self.res and 0 <= py < self.res:
            alpha = min(240, int(140 + normal_force * 35))
            # Main ink stamp
            self.draw.ellipse([px - pr, py - pr, px + pr, py + pr], fill=(16, 16, 16, alpha))
            # Subtle capillary bleed outer halo
            if bleed_factor > 0.1:
                p_bleed = int(pr * (1.0 + bleed_factor * 0.35))
                self.draw.ellipse([px - p_bleed, py - p_bleed, px + p_bleed, py + p_bleed], outline=(30, 25, 20, 30), width=1)

    def clear(self):
        self.image = Image.new("RGBA", (self.res, self.res), (251, 247, 238, 255))
        self.draw = ImageDraw.Draw(self.image)
        self.draw_grid()


# ==============================================================================
# 3. Calligraphy Trajectories (永字八法 & Classical Characters)
# ==============================================================================
# Trajectories centered in the Xuan paper workspace: X in [0.45, 0.65], Y in [-0.10, 0.10]
CALLIGRAPHY_TRAJECTORIES = {
    # 永 (Yong - The 8 Principles: Ce, Le, Nu, Di, Ce, Lve, Zhuo, Zhe)
    "yong": [
        # 1. 点 (Ce / Dot)
        [
            (0.550, 0.000, 0.020, 0.0),
            (0.548, 0.003, -0.003, 0.8),
            (0.545, 0.006, -0.006, 1.2),
            (0.543, 0.003, -0.002, 0.5),
            (0.544, 0.001, 0.025, 0.0)
        ],
        # 2. 横 (Le / Horizontal)
        [
            (0.525, -0.055, 0.020, 0.0),
            (0.524, -0.052, -0.004, 0.8),
            (0.523, -0.020, -0.003, 0.7),
            (0.522, 0.015, -0.003, 0.7),
            (0.521, 0.048, -0.006, 1.1),
            (0.523, 0.044, 0.020, 0.0)
        ],
        # 3. 竖 (Nu / Vertical)
        [
            (0.530, 0.000, 0.020, 0.0),
            (0.526, 0.000, -0.005, 1.0),
            (0.495, 0.000, -0.004, 0.8),
            (0.465, -0.001, -0.004, 0.8),
            (0.435, -0.002, -0.006, 1.1)
        ],
        # 4. 钩 (Di / Hook)
        [
            (0.435, -0.002, -0.006, 1.1),
            (0.433, -0.006, -0.007, 1.3),
            (0.442, -0.015, -0.003, 0.6),
            (0.455, -0.026, 0.025, 0.0)
        ],
        # 5. 提 (Ce / Rising)
        [
            (0.465, -0.045, 0.020, 0.0),
            (0.463, -0.042, -0.004, 0.9),
            (0.472, -0.030, -0.003, 0.6),
            (0.485, -0.012, -0.001, 0.3),
            (0.490, -0.005, 0.020, 0.0)
        ],
        # 6. 撇 (Lve / Long Slanted)
        [
            (0.510, 0.010, 0.020, 0.0),
            (0.508, 0.012, -0.005, 1.0),
            (0.490, 0.000, -0.004, 0.7),
            (0.470, -0.018, -0.003, 0.5),
            (0.448, -0.038, -0.001, 0.3),
            (0.430, -0.055, 0.025, 0.0)
        ],
        # 7. 短撇 (Zhuo / Peck)
        [
            (0.485, 0.015, 0.020, 0.0),
            (0.483, 0.018, -0.004, 0.8),
            (0.472, 0.010, -0.002, 0.4),
            (0.462, 0.002, 0.020, 0.0)
        ],
        # 8. 捺 (Zhe / Pressing Down-Right)
        [
            (0.468, 0.012, 0.020, 0.0),
            (0.465, 0.015, -0.003, 0.5),
            (0.450, 0.028, -0.005, 0.9),
            (0.435, 0.042, -0.007, 1.3),
            (0.428, 0.058, -0.004, 0.7),
            (0.424, 0.075, 0.025, 0.0)
        ]
    ],
    # 一 (Yi - Horizontal)
    "yi": [
        [
            (0.550, -0.070, 0.020, 0.0),
            (0.548, -0.065, -0.003, 0.6),
            (0.547, -0.067, -0.006, 1.1),
            (0.546, -0.030, -0.004, 0.7),
            (0.545, 0.010, -0.004, 0.7),
            (0.544, 0.050, -0.004, 0.8),
            (0.543, 0.065, -0.007, 1.3),
            (0.545, 0.060, 0.025, 0.0)
        ]
    ]
}


# ==============================================================================
# 4. Main Simulation Loop & Viser Interactive Studio
# ==============================================================================
def main():
    print("=" * 70)
    print("  Franka Emika Panda Chinese Calligraphy Simulator (Viser)")
    print("=" * 70)

    # 1. Start Viser Server
    server = viser.ViserServer(port=8080)
    server.initial_camera.position = (1.4, -0.9, 1.1)
    server.initial_camera.look_at = (0.5, 0.0, 0.3)
    server.initial_camera.up = (0.0, 0.0, 1.0)

    # 2. Add Studio Environment (Calligraphy Table, Xuan Paper, Scholar's Items)
    table_pos = (0.55, 0.0, 0.0)
    server.scene.add_grid("/ground", width=3.0, height=3.0, position=(0, 0, -0.4))
    
    # Rosewood Calligraphy Table
    server.scene.add_box(
        "/studio/table",
        dimensions=(0.60, 0.80, 0.04),
        position=(0.55, 0.0, -0.02),
        color=(45, 30, 22),
    )

    # Xuan Paper Canvas
    paper = XuanPaperCanvas(resolution=1024, physical_width=0.36, physical_height=0.36, origin_xy=(0.55, 0.0))
    paper_handle = server.scene.add_image(
        "/studio/xuan_paper",
        image=np.array(paper.image.convert("RGB")),
        render_width=paper.pw,
        render_height=paper.ph,
        position=(paper.ox, paper.oy, 0.001),
        wxyz=(1.0, 0.0, 0.0, 0.0),
    )

    # Brass Paperweight
    server.scene.add_box(
        "/studio/paperweight_left",
        dimensions=(0.025, 0.30, 0.012),
        position=(0.35, 0.0, 0.007),
        color=(185, 145, 60),
    )
    server.scene.add_box(
        "/studio/paperweight_right",
        dimensions=(0.025, 0.30, 0.012),
        position=(0.75, 0.0, 0.007),
        color=(185, 145, 60),
    )

    # 3. Load Franka Emika Panda Model
    kinematics = PandaKinematics(tool_length=0.20)
    brush_tuft = CalligraphyBrushTuft(length=0.045, stiffness=1.2, splay_factor=1.4)
    current_q = kinematics.NOMINAL_REST_Q.copy()

    viser_urdf = None
    if HAS_ROBOT_DESCRIPTIONS:
        try:
            print("[INFO] Loading official Franka Emika Panda description via robot_descriptions...")
            urdf = load_robot_description("panda_description", load_meshes=True, build_scene_graph=True)
            viser_urdf = ViserUrdf(server, urdf_or_path=urdf, root_node_name="/franka_panda")
            viser_urdf.update_cfg(current_q)
            print("[INFO] Franka Panda URDF and meshes loaded successfully!")
        except Exception as e:
            print(f"[WARN] Could not load meshes via robot_descriptions: {e}. Using geometric representation.")

    # 4. End-Effector Calligraphy Brush Attachment
    brush_frame = server.scene.add_frame("/franka_panda/brush_tcp", show_axes=True, axes_length=0.06, axes_radius=0.003)
    
    # Bamboo Handle & Ferrule visual
    brush_handle = server.scene.add_cylinder(
        "/franka_panda/brush_tcp/handle",
        radius=0.006,
        length=0.15,
        position=(0.0, 0.0, 0.08),
        color=(140, 95, 50),
    )
    brush_ferrule = server.scene.add_cylinder(
        "/franka_panda/brush_tcp/ferrule",
        radius=0.0075,
        length=0.025,
        position=(0.0, 0.0, 0.01),
        color=(25, 25, 25),
    )

    # 5. Viser Interactive GUI Controls
    with server.gui.add_folder("Calligraphy Trajectory Execution"):
        char_selector = server.gui.add_dropdown(
            "Character",
            options=list(CALLIGRAPHY_TRAJECTORIES.keys()),
            initial_value="yong"
        )
        btn_play = server.gui.add_button("Execute Character (Write)")
        btn_step = server.gui.add_button("Step Stroke")
        btn_reset = server.gui.add_button("Reset Arm Pose")
        slider_speed = server.gui.add_slider("Writing Speed", min=0.2, max=3.0, step=0.1, initial_value=1.0)
        chk_loop = server.gui.add_checkbox("Loop Playback", False)

    with server.gui.add_folder("Manual Cartesian IK Jogging"):
        slider_ik_x = server.gui.add_slider("TCP X (Reach)", min=0.35, max=0.75, step=0.002, initial_value=0.55)
        slider_ik_y = server.gui.add_slider("TCP Y (Lateral)", min=-0.18, max=0.18, step=0.002, initial_value=0.0)
        slider_ik_z = server.gui.add_slider("TCP Z (Height/Press)", min=-0.01, max=0.08, step=0.001, initial_value=0.03)
        btn_touch_paper = server.gui.add_button("Touch Paper (Z=0)")
        btn_lift_safe = server.gui.add_button("Lift Brush (Z=40mm)")

    with server.gui.add_folder("Joint Angles (7-DOF Franka Panda)"):
        joint_sliders = []
        for i, (low, high) in enumerate(PandaKinematics.JOINT_LIMITS):
            js = server.gui.add_slider(
                f"panda_joint{i+1}",
                min=low,
                max=high,
                step=0.01,
                initial_value=float(current_q[i])
            )
            joint_sliders.append(js)

    with server.gui.add_folder("Tuft & Xuan Paper Physics"):
        slider_stiffness = server.gui.add_slider("Bristle Stiffness", min=0.5, max=2.5, step=0.1, initial_value=1.2)
        slider_splay = server.gui.add_slider("Splay Factor (铺毫)", min=0.8, max=2.5, step=0.1, initial_value=1.4)
        slider_bleed = server.gui.add_slider("Paper Absorbency", min=0.0, max=2.0, step=0.1, initial_value=0.7)
        btn_clear = server.gui.add_button("Wash Paper (Clear)")
        btn_dip = server.gui.add_button("Dip Ink (100%)")

    # GUI Callbacks
    @btn_clear.on_click
    def _(_):
        paper.clear()
        paper_handle.image = np.array(paper.image.convert("RGB"))

    @btn_dip.on_click
    def _(_):
        brush_tuft.ink_level = 100.0

    @btn_touch_paper.on_click
    def _(_):
        slider_ik_z.value = 0.0

    @btn_lift_safe.on_click
    def _(_):
        slider_ik_z.value = 0.04

    # Trajectory execution state
    play_state = {
        "running": False,
        "char": "yong",
        "stroke_idx": 0,
        "point_idx": 0,
        "t": 0.0,
        "last_tip": np.array([0.55, 0.0, 0.03])
    }

    @btn_play.on_click
    def _(_):
        play_state["running"] = not play_state["running"]
        btn_play.label = "Pause Writing" if play_state["running"] else "Resume Writing"

    @btn_step.on_click
    def _(_):
        play_state["running"] = False
        btn_play.label = "Resume Writing"
        char_strokes = CALLIGRAPHY_TRAJECTORIES[char_selector.value]
        play_state["stroke_idx"] = (play_state["stroke_idx"] + 1) % len(char_strokes)
        play_state["point_idx"] = 0
        play_state["t"] = 0.0

    @btn_reset.on_click
    def _(_):
        nonlocal current_q
        play_state["running"] = False
        play_state["stroke_idx"] = 0
        play_state["point_idx"] = 0
        play_state["t"] = 0.0
        btn_play.label = "Execute Character (Write)"
        current_q = kinematics.NOMINAL_REST_Q.copy()
        if viser_urdf:
            viser_urdf.update_cfg(current_q)
        for i, js in enumerate(joint_sliders):
            js.value = float(current_q[i])

    # 6. Main Simulation Tick Loop
    print("
[READY] Viser Chinese Calligraphy Simulator is running!")
    print("👉 Open your browser at: http://localhost:8080
")

    last_time = time.time()
    while True:
        now = time.time()
        dt = min(0.1, now - last_time)
        last_time = now

        # Update physics settings from GUI
        brush_tuft.stiffness = slider_stiffness.value
        brush_tuft.splay_factor = slider_splay.value
        bleed = slider_bleed.value

        # A. Trajectory Player
        if play_state["running"]:
            char_strokes = CALLIGRAPHY_TRAJECTORIES[char_selector.value]
            if play_state["stroke_idx"] < len(char_strokes):
                stroke = char_strokes[play_state["stroke_idx"]]
                p_idx = play_state["point_idx"]

                if p_idx + 1 < len(stroke):
                    p0 = stroke[p_idx]
                    p1 = stroke[p_idx + 1]

                    play_state["t"] += dt * slider_speed.value * 2.2
                    alpha = min(1.0, play_state["t"])
                    smooth_t = alpha * alpha * (3.0 - 2.0 * alpha)

                    target_x = p0[0] + (p1[0] - p0[0]) * smooth_t
                    target_y = p0[1] + (p1[1] - p0[1]) * smooth_t
                    target_z = p0[2] + (p1[2] - p0[2]) * smooth_t

                    target_pos = np.array([target_x, target_y, target_z])
                    current_q = kinematics.solve_ik(target_pos, current_q)

                    if play_state["t"] >= 1.0:
                        play_state["t"] = 0.0
                        play_state["point_idx"] += 1
                else:
                    # Stroke finished -> move to next stroke
                    play_state["stroke_idx"] += 1
                    play_state["point_idx"] = 0
                    play_state["t"] = 0.0
            else:
                # Finished character
                if chk_loop.value:
                    play_state["stroke_idx"] = 0
                    play_state["point_idx"] = 0
                    play_state["t"] = 0.0
                    paper.clear()
                    paper_handle.image = np.array(paper.image.convert("RGB"))
                else:
                    play_state["running"] = False
                    btn_play.label = "Replay Character"

            # Sync sliders
            for i, js in enumerate(joint_sliders):
                js.value = float(current_q[i])

        # B. Apply Joint Configuration to Viser URDF
        if viser_urdf is not None:
            viser_urdf.update_cfg(current_q)

        # C. Update End-Effector Brush Pose
        tip_pos, tip_rot = kinematics.forward_kinematics(current_q)
        brush_frame.position = tip_pos
        # Convert rotation matrix to quaternion (wxyz)
        q_wxyz = tf.SO3.from_matrix(tip_rot).wxyz
        brush_frame.wxyz = q_wxyz

        # D. Deformable Tuft Physics & Xuan Paper Ink Transfer
        velocity = (tip_pos - play_state["last_tip"]) / max(1e-4, dt)
        play_state["last_tip"] = tip_pos.copy()

        contact_info = brush_tuft.evaluate_contact(tip_pos, velocity)
        if contact_info["contact"]:
            actual_tip = contact_info["actual_tip"]
            fn = contact_info["normal_force"]
            fr = contact_info["footprint_radius"]

            # Deposit ink
            paper.deposit_ink(actual_tip[0], actual_tip[1], fr, fn, bleed_factor=bleed)
            paper_handle.image = np.array(paper.image.convert("RGB"))

        time.sleep(0.015)

if __name__ == "__main__":
    main()
