# Franka Emika Panda Robotic Calligraphy Simulator (Viser)
## Comprehensive Local Setup & Execution Guide

This guide will walk you through running the Franka Emika Panda Robotic Chinese Calligraphy simulation on your local computer using **Viser** (the interactive 3D robotics visualizer developed at UC Berkeley).

---

## 1. Prerequisites

- **Operating System**: Linux (Ubuntu 20.04/22.04+), macOS (Intel or Apple Silicon), or Windows 10/11 (PowerShell or WSL2).
- **Python Version**: Python 3.8, 3.9, 3.10, or 3.11 (Python 3.10 or 3.11 recommended).
- **Web Browser**: Any modern browser (Google Chrome, Firefox, Microsoft Edge, Safari).
- **Hardware**: Any modern standard CPU (GPU acceleration is optional; Viser renders client-side WebGL in your browser).

---

## 2. Installation Steps

### Step 2.1: Clone or Extract the Toolkit
If you downloaded the zip package, extract it into your project folder:
```bash
unzip calligraphy_panda_viser_toolkit.zip -d panda_calligraphy
cd panda_calligraphy
```

### Step 2.2: Create and Activate a Python Virtual Environment
Creating an isolated virtual environment prevents library conflicts with your system packages:

**On Linux / macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**On Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

*(If execution policy errors occur on Windows PowerShell, run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`)*

### Step 2.3: Install Required Dependencies
Install the required packages using the provided `requirements.txt`:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

#### What each package does:
- `viser`: The interactive 3D WebGL robotics server and GUI manager.
- `robot_descriptions[panda]`: Automatically downloads and manages the official Franka Emika Panda URDF and visual mesh assets.
- `yourdfpy`: Fast, robust URDF parser with scene graph and kinematic tree traversal.
- `numpy` & `scipy`: Vectorized 7-DOF kinematics, Jacobian calculations, and spline interpolation.
- `Pillow` (PIL): 2D dynamic Xuan paper canvas rasterization, ink bleed, and footprint stamping.
- `trimesh`: 3D geometry processing for robot collision and visual meshes.

---

## 3. Running the Simulation Locally

Launch the simulation script:
```bash
python calligraphy_panda_viser_sim.py
```

You will see output in your terminal:
```text
======================================================================
  Franka Emika Panda Chinese Calligraphy Simulator (Viser)
======================================================================
[INFO] Loading Franka Emika Panda robot description...
[INFO] Franka Panda URDF and meshes initialized successfully.
[INFO] Attached Calligraphy Brush to end-effector link (panda_link8).
[INFO] Initialized 1024x1024 Xuan Paper Canvas with 米字格 (Mi-Grid).
[INFO] Viser Server active at: http://localhost:8080
======================================================================
```

Now open your web browser and navigate to:
👉 **`http://localhost:8080`**

---

## 4. How to Use the Interactive Interface

Once connected to `http://localhost:8080`, you will see the 3D studio featuring the Franka Emika Panda arm mounted on a scholar's wooden workbench above a sheet of Xuan paper.

### 4.1 Navigation Controls
- **Rotate View**: Left-click + drag
- **Pan View**: Right-click + drag (or Shift + Left-click)
- **Zoom**: Mouse scroll wheel

### 4.2 GUI Control Panels (Right-Hand Sidebar)

1. **Character Trajectories (永字八法)**:
   - Select between classical characters:
     - **永 (Yǒng)**: The Eight Principles of Yong (contains all 8 foundational strokes).
     - **福 (Fú)**: Fortune / Blessing (complex radicals and rhythmic balance).
     - **中 (Zhōng)**: Center / Symmetry (sharp needle vertical 悬针竖).
     - **一 (Yī)**: The fundamental horizontal stroke (demonstrates 藏锋 entry and 回锋 finish).
   - Click **"Execute Character"** to watch the Panda arm trace the strokes in real time.
   - Use the **Speed Slider** (0.2x to 3.0x) to observe stroke transitions in slow motion.
   - Use the **"Step"** button to advance stroke by stroke.

2. **Manual Cartesian IK Jogging**:
   - Switch mode to **Manual IK**.
   - Use the **X**, **Y**, **Z** sliders to move the brush tip across the paper.
   - Adjust **Brush Tilt** to toggle between *centered tip* (中锋, 0°) and *slanted tip* (侧锋, ±15°).
   - Watch the 7 Panda joints automatically articulate through damped least-squares inverse kinematics!

3. **Joint Position Control**:
   - Expand the **"Joint Angles (7-DOF Panda)"** folder.
   - Adjust individual joints (`panda_joint1` through `panda_joint7`) within their official Franka hardware limits.

4. **Brush & Paper Physics**:
   - **Bristle Stiffness**: Soft (Goat/羊毫), Medium (Wolf/狼毫), or Firm (Purple/紫毫).
   - **Splay Factor**: Controls how much the tuft widens under downward pressure (按笔).
   - **Paper Absorbency**: Simulates Raw Xuan paper (生宣, high capillary bleed) vs. Sized paper (熟宣, sharp edge).
   - **Wash Paper**: Clears the ink from the Xuan paper.
   - **Dip Ink**: Replenishes the brush ink reservoir to 100%.

---

## 5. Technical Architecture

### 5.1 7-DOF Kinematic Chain
The Franka Emika Panda is a 7-axis kinematic manipulator:
$$oldsymbol{q} = [q_1, q_2, q_3, q_4, q_5, q_6, q_7]^T$$

Joint Limits (radians):
- $q_1 \in [-2.8973, 2.8973]$ (Base yaw)
- $q_2 \in [-1.7628, 1.7628]$ (Shoulder pitch)
- $q_3 \in [-2.8973, 2.8973]$ (Shoulder roll)
- $q_4 \in [-3.0718, -0.0698]$ (Elbow pitch)
- $q_5 \in [-2.8973, 2.8973]$ (Forearm roll)
- $q_6 \in [-0.0175, 3.7525]$ (Wrist pitch)
- $q_7 \in [-2.8973, 2.8973]$ (Wrist roll)

The inverse kinematics algorithm uses Damped Least Squares (DLS) with nullspace biasing toward a comfortable nominal posture:
$$\Delta oldsymbol{q} = oldsymbol{J}^T \left( oldsymbol{J} oldsymbol{J}^T + \lambda^2 oldsymbol{I} ight)^{-1} \Delta oldsymbol{x} + \left( oldsymbol{I} - oldsymbol{J}^\dagger oldsymbol{J} ight) k_0 (oldsymbol{q}_{	ext{rest}} - oldsymbol{q})$$

### 5.2 Deformable Tuft Mechanics
When the brush penetrates the paper surface ($z \le z_{	ext{paper}}$, depth $\delta = z_{	ext{paper}} - z$):
- **Normal Force**: $F_N = K_{	ext{stiff}} \cdot \delta^{1.25}$ (Hertzian contact elasticity).
- **Splayed Footprint Radius**: $R_{	ext{footprint}} = R_0 + \kappa_{	ext{splay}} \cdot \sqrt{\delta}$.
- **Bending Lag**: When the arm travels with planar velocity $ec{v}$, friction causes the tip to lag behind the ferrule:
  $$\Delta ec{x}_{	ext{lag}} = -rac{ec{v}}{\|ec{v}\| + \epsilon} \cdot \min(d_{	ext{max}}, \delta \cdot eta)$$

---

## 6. Running on a Remote Headless Server / Cloud Instance

If you are running the script on a remote GPU server or cloud instance:
1. Start the script on the remote server:
   ```bash
   python calligraphy_panda_viser_sim.py --port 8080
   ```
2. On your local machine, open an SSH tunnel:
   ```bash
   ssh -N -L 8080:localhost:8080 username@remote-server-ip
   ```
3. Open `http://localhost:8080` in your local computer's browser.

---

## 7. Troubleshooting

- **Port 8080 already in use**:
  Pass a custom port: `python calligraphy_panda_viser_sim.py --port 8085` and visit `http://localhost:8085`.
- **`ModuleNotFoundError: No module named 'robot_descriptions'`**:
  Make sure you ran `pip install -r requirements.txt`. If needed, install manually via:
  `pip install "robot_descriptions[panda]"`
- **Meshes take a few seconds to load on first launch**:
  `robot_descriptions` automatically downloads and caches Franka Panda COLLADA/STL meshes to `~/.cache/robot_descriptions/`. This happens once on the very first run. The script includes an automated fallback that will display geometric link cylinders if offline.
